from django.contrib import admin
from .models import Booking
from .models import Driver
# Register your models here.
admin.site.register(Booking)
admin.site.register(Driver)
