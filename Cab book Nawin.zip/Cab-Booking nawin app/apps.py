from django.apps import AppConfig


class BookingappConfig(AppConfig):
    name = 'bookingapp'
